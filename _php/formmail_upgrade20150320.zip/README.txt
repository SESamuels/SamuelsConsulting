This ZIP file is a package created for you at Mar 20 2015 16:28:08 GMT
by the FormMail Upgrade wizard from www.tectite.com.

The package contains at least two other files:
  formmail-old.php - the old FormMail you uploaded for conversion
                     (which was originally called 'formmail.php')
  formmail.php     - the new version of FormMail with your
                     configuration copied from formmail-old.php

Any new configuration settings are set to a default value.
You may like to review the documentation in formmail.php for
new settings and change them for your installation.

Don't forget!  You can follow us on Twitter: http://twitter.com/tectitecom

----------------

The following informative messages were produced during conversion:

The FormMail version you uploaded was: 9.10
The new FormMail version is: 9.10